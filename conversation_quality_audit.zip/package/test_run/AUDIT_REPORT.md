# AmazonHelp Conversation Quality Audit

Dataset rows: 92,485
AmazonHelp tweets: 6,378
AmazonHelp-connected root components: 2,769

## Component audit
| Status | Count | Share |
|---|---:|---:|
| KEEP | 1,610 | 58.14% |
| FLAG | 102 | 3.68% |
| EXCLUDE | 1,057 | 38.17% |

## Customer problem episodes
Direct customer -> AmazonHelp episodes: 4,246

| Status | Count | Share |
|---|---:|---:|
| KEEP | 3,999 | 94.18% |
| FLAG | 194 | 4.57% |
| EXCLUDE | 53 | 1.25% |

## Important methodology
- Short messages, multilingual signals, URLs, and acknowledgments are not blindly deleted at the raw-data stage.
- Component quality and episode quality are reported separately.
- The customer problem corpus for intent discovery should use the episode table, not AmazonHelp replies as clustering text.
- Historical AmazonHelp replies are retained separately for later response-evidence retrieval.
- Thresholds are configurable and should be validated by manual inspection before being frozen in the report.