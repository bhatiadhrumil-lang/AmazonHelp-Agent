# Conversation Quality Audit

This stage converts the Customer Support on Twitter data into a quality-controlled AmazonHelp conversation corpus before intent discovery.

## What it does

1. Loads `twcs.csv` (or `archive.zip`).
2. Reconstructs reply-chain root components from `in_response_to_tweet_id`.
3. Selects components connected to `AmazonHelp`.
4. Audits components using:
   - broken/missing parent-chain signals
   - large time gaps
   - long/extreme conversation length
   - presence of direct customer -> AmazonHelp interactions
5. Builds customer-problem episodes from direct customer -> AmazonHelp interactions.
6. Adds review flags for short/acknowledgment-like, multilingual-script, URL and timing signals.
7. Writes CSV/JSON/Markdown artifacts.

## Important methodology

The audit intentionally does **not** delete every short message, URL, multilingual message, or template. These are review signals. A message such as `Where is it?` can be a valid intent when context is available, while `Thanks` usually is not an intent-bearing problem.

AmazonHelp replies are not used as the text to cluster. They are retained as response evidence for the later response-generation stage.

## Run

From the repository root:

```bash
python src/data/conversation_quality_audit.py data/twcs/twcs.csv \
  --out artifacts/conversation_audit
```

If the dataset is still zipped:

```bash
python src/data/conversation_quality_audit.py data/archive.zip \
  --out artifacts/conversation_audit
```

Optional thresholds:

```bash
python src/data/conversation_quality_audit.py data/twcs/twcs.csv \
  --gap-flag-hours 72 \
  --long-conversation-flag 30 \
  --very-long-conversation-exclude 150 \
  --out artifacts/conversation_audit
```

## Outputs

- `conversation_components_audit.csv` — one row per AmazonHelp-connected root component.
- `customer_problem_episodes.csv` — direct customer -> AmazonHelp episodes for intent discovery review.
- `audit_summary.json` — machine-readable counts and quantiles.
- `AUDIT_REPORT.md` — concise human-readable summary.

## Current decision

The thresholds are **initial audit rules, not final scientific claims**. Before freezing them in the report, manually inspect samples from KEEP, FLAG and EXCLUDE and adjust if the examples show systematic false exclusions.
